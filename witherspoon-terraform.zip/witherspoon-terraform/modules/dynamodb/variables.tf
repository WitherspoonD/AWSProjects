# modules/dynamodb/variables.tf
variable "project_name" { type = string }
